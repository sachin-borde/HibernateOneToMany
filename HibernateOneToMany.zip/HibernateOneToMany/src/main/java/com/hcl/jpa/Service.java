package com.hcl.jpa;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class Service {

	private static SessionFactory factory = new AnnotationConfiguration().configure().buildSessionFactory();

	public static void main(String[] args) {

		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();

		Employee e1 = new Employee("SWARA", 435656.89);
		session.save(e1);

		Address a1 = new Address("INSPIRIA MALL", "PCMC", "INDIA", "MH", 411044, e1);
		Address a2 = new Address("AMANORA MALL", "PUNE", "INDIA", "MH", 411028, e1);
		session.save(a1);
		session.save(a2);
		transaction.commit();
	}
}
