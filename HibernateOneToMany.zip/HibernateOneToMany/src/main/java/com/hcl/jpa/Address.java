package com.hcl.jpa;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Address {

	@Id
	@GeneratedValue
	private int addressId;
	private String addressStreet;
	private String addressCity;
	private String addressCountry;
	private String addressState;
	private int addressPinCode;
	
	@ManyToOne
	private Employee employee;

	public Address(String addressStreet, String addressCity, String addressCountry, String addressState,
			int addressPinCode, Employee employee) {
		super();
		this.addressStreet = addressStreet;
		this.addressCity = addressCity;
		this.addressCountry = addressCountry;
		this.addressState = addressState;
		this.addressPinCode = addressPinCode;
		this.employee = employee;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getAddressStreet() {
		return addressStreet;
	}

	public void setAddressStreet(String addressStreet) {
		this.addressStreet = addressStreet;
	}

	public String getAddressCity() {
		return addressCity;
	}

	public void setAddressCity(String addressCity) {
		this.addressCity = addressCity;
	}

	public String getAddressCountry() {
		return addressCountry;
	}

	public void setAddressCountry(String addressCountry) {
		this.addressCountry = addressCountry;
	}

	public String getAddressState() {
		return addressState;
	}

	public void setAddressState(String addressState) {
		this.addressState = addressState;
	}

	public int getAddressPinCode() {
		return addressPinCode;
	}

	public void setAddressPinCode(int addressPinCode) {
		this.addressPinCode = addressPinCode;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
}
