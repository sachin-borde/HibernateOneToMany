# Spring Profiles in Spring Boot Application

- Environment variable used to load a specific profile - `spring.profiles.active=dev`